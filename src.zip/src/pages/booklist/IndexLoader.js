import React from "react";
//material ui imports
import CircularProgress from "@material-ui/core/CircularProgress";

export default function CircularUnderLoad() {
  return <CircularProgress disableShrink />;
}
